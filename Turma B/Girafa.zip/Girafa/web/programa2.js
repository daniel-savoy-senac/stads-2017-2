function iniciar(){
	document.querySelector("button").addEventListener("click", enviar);
}

function enviar(){
	let formu = document.querySelector("form");
	let url = formu.getAttribute("action");
	let data = new FormData(formu);
	
	//let obj = {nome: "daniel", idade:36};
	//let json = JSON.stringify(obj);
	
	fetch(url, {method: "post", body: data, credentials: "include"})
                .then(r => r.text())
                .then(t => console.log(t));
}

window.addEventListener("load", iniciar);